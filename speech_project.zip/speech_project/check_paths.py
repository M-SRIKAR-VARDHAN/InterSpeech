#!/usr/bin/env python3
"""
check_paths.py - Verify all data paths are correct before processing
Run this first to make sure everything is set up correctly.
"""

import sys
from pathlib import Path

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent))

from config import RAW_DATA, UNIFIED_DIR, DATASETS

def check_paths():
    print("=" * 60)
    print("PATH VERIFICATION")
    print("=" * 60)
    
    all_ok = True
    
    # Check VCTK
    print("\n[VCTK]")
    vctk_audio = RAW_DATA["vctk_audio"]
    vctk_text = RAW_DATA["vctk_text"]
    vctk_info = RAW_DATA["vctk_speaker_info"]
    
    if vctk_audio.exists():
        speakers = list(vctk_audio.iterdir())
        print(f"  ✓ Audio dir: {vctk_audio}")
        print(f"    Found {len(speakers)} speaker directories")
        # Count some files
        sample_spk = speakers[0] if speakers else None
        if sample_spk:
            files = list(sample_spk.glob("*.flac"))
            print(f"    Sample: {sample_spk.name} has {len(files)} FLAC files")
    else:
        print(f"  ✗ Audio dir NOT FOUND: {vctk_audio}")
        all_ok = False
    
    if vctk_text.exists():
        print(f"  ✓ Text dir: {vctk_text}")
    else:
        print(f"  ✗ Text dir NOT FOUND: {vctk_text}")
        all_ok = False
    
    if vctk_info.exists():
        print(f"  ✓ Speaker info: {vctk_info}")
    else:
        print(f"  ✗ Speaker info NOT FOUND: {vctk_info}")
        all_ok = False
    
    # Check ESD
    print("\n[ESD]")
    esd_dir = RAW_DATA["esd"]
    
    if esd_dir.exists():
        print(f"  ✓ ESD dir: {esd_dir}")
        
        # Check English speakers
        english_speakers = DATASETS["esd"]["english_speakers"]
        found = []
        missing = []
        
        for spk_id in english_speakers:
            spk_dir = esd_dir / spk_id
            if spk_dir.exists():
                found.append(spk_id)
            else:
                missing.append(spk_id)
        
        print(f"    English speakers found: {len(found)}/{len(english_speakers)}")
        if missing:
            print(f"    MISSING: {missing}")
            all_ok = False
        
        # Check emotions for one speaker
        if found:
            sample_spk = found[0]
            spk_dir = esd_dir / sample_spk
            emotions_found = []
            for emotion in DATASETS["esd"]["emotions"]:
                if (spk_dir / emotion).exists():
                    emotions_found.append(emotion)
            print(f"    Sample {sample_spk} emotions: {emotions_found}")
            
            # Count files in one emotion
            sample_emotion_dir = spk_dir / emotions_found[0]
            wav_count = len(list(sample_emotion_dir.glob("*.wav")))
            print(f"    Sample {sample_spk}/{emotions_found[0]}: {wav_count} WAV files")
            
            # Check transcript
            transcript_file = spk_dir / f"{sample_spk}.txt"
            if transcript_file.exists():
                print(f"    ✓ Transcript file exists: {transcript_file.name}")
            else:
                print(f"    ✗ Transcript file NOT FOUND: {transcript_file}")
    else:
        print(f"  ✗ ESD dir NOT FOUND: {esd_dir}")
        all_ok = False
    
    # Check output directory
    print("\n[OUTPUT]")
    print(f"  Output will be written to: {UNIFIED_DIR}")
    if UNIFIED_DIR.exists():
        print(f"  (Directory already exists)")
    else:
        print(f"  (Directory will be created)")
    
    # Summary
    print("\n" + "=" * 60)
    if all_ok:
        print("✓ ALL PATHS VERIFIED - Ready to run stage1_create_dataset.py")
    else:
        print("✗ SOME PATHS MISSING - Fix config.py before proceeding")
    print("=" * 60)
    
    return all_ok


def check_dependencies():
    """Check if required packages are installed."""
    print("\n[DEPENDENCIES]")
    
    packages = ["numpy", "pandas", "librosa", "soundfile"]
    all_ok = True
    
    for pkg in packages:
        try:
            __import__(pkg)
            print(f"  ✓ {pkg}")
        except ImportError:
            print(f"  ✗ {pkg} NOT INSTALLED")
            all_ok = False
    
    if not all_ok:
        print("\n  Install missing packages with:")
        print("  pip install -r requirements.txt")
    
    return all_ok


def test_audio_loading():
    """Test loading one audio file from each dataset."""
    print("\n[AUDIO LOADING TEST]")
    
    try:
        import librosa
        import soundfile as sf
        
        # Test VCTK
        vctk_audio = RAW_DATA["vctk_audio"]
        if vctk_audio.exists():
            # Find first FLAC file
            for spk_dir in vctk_audio.iterdir():
                if spk_dir.is_dir():
                    flac_files = list(spk_dir.glob("*.flac"))
                    if flac_files:
                        test_file = flac_files[0]
                        audio, sr = librosa.load(test_file, sr=16000)
                        print(f"  ✓ VCTK: Loaded {test_file.name}")
                        print(f"    Original -> 16kHz, {len(audio)/sr:.2f}s")
                        break
        
        # Test ESD
        esd_dir = RAW_DATA["esd"]
        if esd_dir.exists():
            for spk_id in DATASETS["esd"]["english_speakers"]:
                spk_dir = esd_dir / spk_id / "Neutral"
                if spk_dir.exists():
                    wav_files = list(spk_dir.glob("*.wav"))
                    if wav_files:
                        test_file = wav_files[0]
                        audio, sr = librosa.load(test_file, sr=16000)
                        print(f"  ✓ ESD: Loaded {test_file.name}")
                        print(f"    16kHz, {len(audio)/sr:.2f}s")
                        break
        
        return True
    except Exception as e:
        print(f"  ✗ Audio loading failed: {e}")
        return False


if __name__ == "__main__":
    paths_ok = check_paths()
    deps_ok = check_dependencies()
    
    if paths_ok and deps_ok:
        audio_ok = test_audio_loading()
    
    if paths_ok and deps_ok:
        print("\n" + "=" * 60)
        print("Ready to run:")
        print("  python stage1_create_dataset.py")
        print("=" * 60)
