"""
utils.py - Utility functions for speech disentanglement project
"""

import json
import numpy as np
import librosa
import soundfile as sf
from pathlib import Path
from datetime import datetime


def load_audio(file_path, target_sr=16000):
    """
    Load audio file and resample to target sample rate.
    
    Args:
        file_path: Path to audio file (WAV, FLAC, etc.)
        target_sr: Target sample rate (default 16000)
    
    Returns:
        tuple: (audio_array, sample_rate, duration_seconds)
        None if loading fails
    """
    try:
        # librosa handles resampling automatically
        audio, sr = librosa.load(file_path, sr=target_sr, mono=True)
        duration = len(audio) / sr
        return audio, sr, duration
    except Exception as e:
        print(f"    ERROR loading {file_path}: {e}")
        return None, None, None


def save_audio(audio, file_path, sr=16000):
    """
    Save audio array to WAV file.
    
    Args:
        audio: numpy array of audio samples
        file_path: Output path
        sr: Sample rate
    """
    # Ensure directory exists
    Path(file_path).parent.mkdir(parents=True, exist_ok=True)
    
    # Save as 16-bit WAV
    sf.write(file_path, audio, sr, subtype='PCM_16')


def load_checkpoint(checkpoint_path):
    """
    Load checkpoint file (list of completed utterance IDs).
    
    Returns:
        set: Set of completed utterance IDs
    """
    if Path(checkpoint_path).exists():
        with open(checkpoint_path, 'r') as f:
            data = json.load(f)
            return set(data.get("completed", []))
    return set()


def save_checkpoint(checkpoint_path, completed_set, extra_info=None):
    """
    Save checkpoint file.
    
    Args:
        checkpoint_path: Path to checkpoint file
        completed_set: Set of completed utterance IDs
        extra_info: Optional dict of extra info to save
    """
    data = {
        "completed": list(completed_set),
        "count": len(completed_set),
        "last_updated": datetime.now().isoformat(),
    }
    if extra_info:
        data.update(extra_info)
    
    with open(checkpoint_path, 'w') as f:
        json.dump(data, f, indent=2)


def load_processing_log(log_path):
    """
    Load processing log (skipped files and reasons).
    
    Returns:
        dict: Log dictionary
    """
    if Path(log_path).exists():
        with open(log_path, 'r') as f:
            return json.load(f)
    return {"skipped": [], "errors": [], "stats": {}}


def save_processing_log(log_path, log_data):
    """
    Save processing log.
    """
    log_data["last_updated"] = datetime.now().isoformat()
    with open(log_path, 'w') as f:
        json.dump(log_data, f, indent=2)


def parse_vctk_speaker_info(info_path):
    """
    Parse VCTK speaker-info.txt file.
    
    Returns:
        dict: speaker_id -> {age, gender, accent, region}
    """
    speakers = {}
    
    if not Path(info_path).exists():
        print(f"WARNING: speaker-info.txt not found at {info_path}")
        return speakers
    
    with open(info_path, 'r', encoding='utf-8', errors='ignore') as f:
        lines = f.readlines()
    
    for line in lines[1:]:  # Skip header
        parts = line.strip().split()
        if len(parts) >= 3:
            spk_id = parts[0]
            age = parts[1] if len(parts) > 1 else ""
            gender = parts[2] if len(parts) > 2 else "U"
            accent = parts[3] if len(parts) > 3 else ""
            region = " ".join(parts[4:]) if len(parts) > 4 else ""
            
            speakers[spk_id] = {
                "age": age,
                "gender": gender,
                "accent": accent,
                "region": region.replace("(", "").replace(")", ""),
            }
    
    return speakers


def parse_esd_transcript(transcript_path):
    """
    Parse ESD transcript file (tab-separated: utt_id, text, emotion).
    
    Returns:
        dict: utt_id -> {text, emotion}
    """
    transcripts = {}
    
    if not Path(transcript_path).exists():
        return transcripts
    
    with open(transcript_path, 'r', encoding='utf-8', errors='ignore') as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            
            parts = line.split('\t')
            if len(parts) >= 3:
                utt_id = parts[0]
                text = parts[1]
                emotion = parts[2]
                transcripts[utt_id] = {
                    "text": text,
                    "emotion": emotion.lower(),
                }
            elif len(parts) == 2:
                # Some lines might not have emotion
                utt_id = parts[0]
                text = parts[1]
                transcripts[utt_id] = {
                    "text": text,
                    "emotion": "unknown",
                }
    
    return transcripts


def print_progress(current, total, prefix="Progress"):
    """
    Print progress bar.
    """
    pct = current / total * 100
    bar_len = 40
    filled = int(bar_len * current / total)
    bar = "█" * filled + "░" * (bar_len - filled)
    print(f"\r{prefix}: [{bar}] {current}/{total} ({pct:.1f}%)", end="", flush=True)


def print_section(title):
    """
    Print section header.
    """
    print()
    print("=" * 60)
    print(title)
    print("=" * 60)
