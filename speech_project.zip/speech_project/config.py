"""
config.py - All configuration for speech disentanglement project
Modify paths here to match your system.
"""

from pathlib import Path

# ============================================================
# PATHS - MODIFY THESE FOR YOUR SYSTEM
# ============================================================

# Base directory (where this script lives)
BASE_DIR = Path(r"D:\InterSpeech")

# Raw data locations
RAW_DATA = {
    "vctk_audio": BASE_DIR / "dataset" / "wav48_silence_trimmed",
    "vctk_text": BASE_DIR / "dataset" / "txt",
    "vctk_speaker_info": BASE_DIR / "dataset" / "speaker-info.txt",
    "esd": BASE_DIR / "dataset" / "Emotion Speech Dataset",
}

# Output directory for unified dataset
UNIFIED_DIR = BASE_DIR / "unified"

# ============================================================
# AUDIO SETTINGS
# ============================================================

AUDIO = {
    "target_sr": 16000,        # Target sample rate (Hz)
    "min_duration": 0.5,       # Minimum duration (seconds)
    "max_duration": 20.0,      # Maximum duration (seconds)
}

# ============================================================
# DATASET SETTINGS
# ============================================================

DATASETS = {
    "vctk": {
        "enabled": True,
        "prefix": "vctk",      # Prefix for utterance IDs
    },
    "esd": {
        "enabled": True,
        "prefix": "esd",
        "english_speakers": [f"{i:04d}" for i in range(11, 21)],  # 0011-0020
        "emotions": ["Angry", "Happy", "Neutral", "Sad", "Surprise"],
    },
}

# ESD speaker gender mapping (from ESD documentation)
# 0011-0015: Female, 0016-0020: Male
ESD_GENDER = {
    "0011": "F", "0012": "F", "0013": "F", "0014": "F", "0015": "F",
    "0016": "M", "0017": "M", "0018": "M", "0019": "M", "0020": "M",
}

# ============================================================
# SPLIT SETTINGS
# ============================================================

SPLITS = {
    "train_ratio": 0.70,
    "val_ratio": 0.15,
    "test_ratio": 0.15,
    "seed": 42,
}

# ============================================================
# KNOWN BAD FILES (from VCTK update.txt)
# ============================================================

VCTK_BAD_FILES = {
    # Deleted due to issues
    "p282_019", "p295_334", "p295_047", "p302_013", "p303_303",
    "p305_423", "p306_114", "p306_140", "p306_235", "p317_424",
    "p330_424", "p335_424", "p345_266", "p345_387", "p345_388",
    "p323_424", "p282_008", "p258_109", "p286_029", "p306_148",
    "p306_149", "p306_150", "p306_152", "p239_083", "p351_361",
    "p306_151", "p295_001", "p300_155", "p306_352", "p254_368",
    "p232_212", "p282_116", "p277_388", "p326_365",
}

# ============================================================
# CHECKPOINT SETTINGS
# ============================================================

CHECKPOINT_INTERVAL = 100  # Save progress every N files
