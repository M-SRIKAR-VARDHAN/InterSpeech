#!/usr/bin/env python3
"""
============================================================
STAGE 1: CREATE UNIFIED DATASET (FIXED)
============================================================
Combines VCTK + ESD (English) into unified 16kHz dataset.

FIXES:
- Uses mic2 only (cleaner audio), fallback to mic1 if unavailable
- Cleans up any wrongly created mic1 files at the end
- Properly handles VCTK bad files from update.txt

INPUT:
  - VCTK: dataset/wav48_silence_trimmed/ (48kHz FLAC)
  - ESD:  dataset/Emotion Speech Dataset/0011-0020/ (16kHz WAV)

OUTPUT:
  - unified/audio_16k/           All audio at 16kHz
  - unified/metadata.csv         All metadata
  - unified/splits.json          Train/val/test splits
  - unified/checkpoint.json      Resume support
  - unified/processing_log.json  Skipped files log

USAGE:
  python stage1_create_dataset.py              # Run full pipeline
  python stage1_create_dataset.py --resume     # Resume from checkpoint
  python stage1_create_dataset.py --vctk-only  # Process only VCTK
  python stage1_create_dataset.py --esd-only   # Process only ESD
  python stage1_create_dataset.py --cleanup    # Only run cleanup
  python stage1_create_dataset.py --fresh      # Delete existing and start fresh

============================================================
"""

import os
import sys
import json
import argparse
import numpy as np
import pandas as pd
from pathlib import Path
from datetime import datetime
from collections import defaultdict

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent))

from config import (
    RAW_DATA, UNIFIED_DIR, AUDIO, DATASETS, ESD_GENDER,
    SPLITS, VCTK_BAD_FILES, CHECKPOINT_INTERVAL
)
from utils import (
    load_audio, save_audio, load_checkpoint, save_checkpoint,
    load_processing_log, save_processing_log, parse_vctk_speaker_info,
    parse_esd_transcript, print_progress, print_section
)


# ============================================================
# VCTK PROCESSING (FIXED - mic2 preferred)
# ============================================================

def get_vctk_utterances(speaker_dir):
    """
    Get unique utterances from speaker directory, preferring mic2 over mic1.
    
    VCTK has two microphones:
    - mic1 (DPA 4035): Has low frequency noise
    - mic2 (MKH 800): Cleaner, recommended
    
    Returns:
        dict: base_name -> Path to best audio file
    """
    all_files = list(speaker_dir.glob("*.flac"))
    
    # Group by utterance base name
    utterance_mics = defaultdict(dict)
    
    for f in all_files:
        stem = f.stem  # e.g., "p225_001_mic1"
        
        if "_mic2" in stem:
            base = stem.replace("_mic2", "")
            utterance_mics[base]["mic2"] = f
        elif "_mic1" in stem:
            base = stem.replace("_mic1", "")
            utterance_mics[base]["mic1"] = f
        else:
            # No mic suffix (shouldn't happen, but handle it)
            utterance_mics[stem]["default"] = f
    
    # Select best mic for each utterance
    selected = {}
    for base_name, mics in utterance_mics.items():
        if "mic2" in mics:
            selected[base_name] = mics["mic2"]
        elif "mic1" in mics:
            selected[base_name] = mics["mic1"]
        elif "default" in mics:
            selected[base_name] = mics["default"]
    
    return selected


def process_vctk(output_dir, checkpoint_path, log_data, resume=False):
    """
    Process VCTK dataset: FLAC 48kHz -> WAV 16kHz
    Uses mic2 (cleaner) by default, falls back to mic1 if needed.
    """
    print_section("Processing VCTK")
    
    audio_dir = RAW_DATA["vctk_audio"]
    text_dir = RAW_DATA["vctk_text"]
    
    if not audio_dir.exists():
        print(f"ERROR: VCTK audio not found at {audio_dir}")
        return []
    
    # Load speaker info
    speaker_info = parse_vctk_speaker_info(RAW_DATA["vctk_speaker_info"])
    print(f"Loaded info for {len(speaker_info)} speakers")
    
    # Load checkpoint if resuming
    completed = load_checkpoint(checkpoint_path) if resume else set()
    if completed:
        print(f"Resuming... {len(completed)} already completed")
    
    # Get all speaker directories
    speaker_dirs = sorted([d for d in audio_dir.iterdir() if d.is_dir()])
    print(f"Found {len(speaker_dirs)} speaker directories")
    
    # Count total UNIQUE utterances (not files - since mic1/mic2 doubles count)
    total_utterances = 0
    for spk_dir in speaker_dirs:
        utterances = get_vctk_utterances(spk_dir)
        total_utterances += len(utterances)
    print(f"Total unique utterances: {total_utterances}")
    
    records = []
    processed_count = 0
    skipped_count = 0
    current_utt = 0
    mic2_count = 0
    mic1_fallback_count = 0
    
    for spk_dir in speaker_dirs:
        spk_id = spk_dir.name  # e.g., "p225"
        unified_spk_id = f"vctk_{spk_id}"
        
        # Get speaker metadata
        info = speaker_info.get(spk_id, {})
        gender = info.get("gender", "U")
        accent = info.get("accent", "")
        region = info.get("region", "")
        
        # Output directory for this speaker
        spk_out_dir = output_dir / "audio_16k" / unified_spk_id
        
        # Get unique utterances (mic2 preferred)
        utterances = get_vctk_utterances(spk_dir)
        
        for base_name, audio_file in sorted(utterances.items()):
            current_utt += 1
            utt_id = f"vctk_{base_name}"
            
            # Track which mic we're using
            is_mic2 = "_mic2" in audio_file.stem
            
            # Skip if in bad files list
            if base_name in VCTK_BAD_FILES:
                log_data["skipped"].append({
                    "utt_id": utt_id,
                    "reason": "known_bad_file",
                    "source": str(audio_file),
                })
                skipped_count += 1
                continue
            
            # Skip if already done (resume mode)
            if utt_id in completed:
                out_path = spk_out_dir / f"{utt_id}.wav"
                if out_path.exists():
                    # Load existing to get duration
                    audio, sr, duration = load_audio(out_path, AUDIO["target_sr"])
                    if audio is not None:
                        # Get transcript
                        txt_file = text_dir / spk_id / f"{base_name}.txt"
                        transcript = ""
                        if txt_file.exists():
                            transcript = txt_file.read_text(encoding='utf-8', errors='ignore').strip()
                        
                        records.append({
                            "utt_id": utt_id,
                            "speaker_id": unified_spk_id,
                            "dataset": "vctk",
                            "audio_path": f"audio_16k/{unified_spk_id}/{utt_id}.wav",
                            "audio_path_original": str(audio_file),
                            "duration": round(duration, 3),
                            "transcript": transcript,
                            "gender": gender,
                            "emotion": "neutral",
                            "accent": accent,
                        })
                continue
            
            # Load and resample audio
            audio, sr, duration = load_audio(audio_file, AUDIO["target_sr"])
            
            if audio is None:
                log_data["errors"].append({
                    "utt_id": utt_id,
                    "reason": "load_failed",
                    "source": str(audio_file),
                })
                skipped_count += 1
                continue
            
            # Check duration constraints
            if duration < AUDIO["min_duration"]:
                log_data["skipped"].append({
                    "utt_id": utt_id,
                    "reason": f"too_short_{duration:.2f}s",
                    "source": str(audio_file),
                })
                skipped_count += 1
                continue
            
            if duration > AUDIO["max_duration"]:
                log_data["skipped"].append({
                    "utt_id": utt_id,
                    "reason": f"too_long_{duration:.2f}s",
                    "source": str(audio_file),
                })
                skipped_count += 1
                continue
            
            # Get transcript
            txt_file = text_dir / spk_id / f"{base_name}.txt"
            transcript = ""
            if txt_file.exists():
                transcript = txt_file.read_text(encoding='utf-8', errors='ignore').strip()
            
            # Save audio
            out_path = spk_out_dir / f"{utt_id}.wav"
            save_audio(audio, out_path, AUDIO["target_sr"])
            
            # Record
            records.append({
                "utt_id": utt_id,
                "speaker_id": unified_spk_id,
                "dataset": "vctk",
                "audio_path": f"audio_16k/{unified_spk_id}/{utt_id}.wav",
                "audio_path_original": str(audio_file),
                "duration": round(duration, 3),
                "transcript": transcript,
                "gender": gender,
                "emotion": "neutral",
                "accent": accent,
            })
            
            completed.add(utt_id)
            processed_count += 1
            
            if is_mic2:
                mic2_count += 1
            else:
                mic1_fallback_count += 1
            
            # Checkpoint periodically
            if processed_count % CHECKPOINT_INTERVAL == 0:
                save_checkpoint(checkpoint_path, completed)
                print_progress(current_utt, total_utterances, "VCTK")
    
    # Final checkpoint
    save_checkpoint(checkpoint_path, completed)
    
    print()
    print(f"VCTK complete:")
    print(f"  Processed: {processed_count}")
    print(f"  Skipped:   {skipped_count}")
    print(f"  Used mic2: {mic2_count}")
    print(f"  Used mic1 (fallback): {mic1_fallback_count}")
    
    return records


# ============================================================
# ESD PROCESSING
# ============================================================

def process_esd(output_dir, checkpoint_path, log_data, resume=False):
    """
    Process ESD dataset (English speakers only): WAV 16kHz -> WAV 16kHz
    """
    print_section("Processing ESD (English)")
    
    esd_dir = RAW_DATA["esd"]
    
    if not esd_dir.exists():
        print(f"ERROR: ESD not found at {esd_dir}")
        return []
    
    english_speakers = DATASETS["esd"]["english_speakers"]
    emotions = DATASETS["esd"]["emotions"]
    
    print(f"Processing {len(english_speakers)} English speakers: {english_speakers}")
    
    # Load checkpoint if resuming
    completed = load_checkpoint(checkpoint_path) if resume else set()
    if completed:
        print(f"Resuming... {len(completed)} already completed")
    
    records = []
    processed_count = 0
    skipped_count = 0
    
    # Count total files
    total_files = 0
    for spk_id in english_speakers:
        spk_dir = esd_dir / spk_id
        if spk_dir.exists():
            for emotion in emotions:
                emotion_dir = spk_dir / emotion
                if emotion_dir.exists():
                    total_files += len(list(emotion_dir.glob("*.wav")))
    
    print(f"Total files to process: {total_files}")
    current_file = 0
    
    for spk_id in english_speakers:
        spk_dir = esd_dir / spk_id
        
        if not spk_dir.exists():
            print(f"  WARNING: Speaker {spk_id} not found")
            continue
        
        unified_spk_id = f"esd_{spk_id}"
        gender = ESD_GENDER.get(spk_id, "U")
        
        # Load transcript file
        transcript_file = spk_dir / f"{spk_id}.txt"
        transcripts = parse_esd_transcript(transcript_file)
        
        # Output directory for this speaker
        spk_out_dir = output_dir / "audio_16k" / unified_spk_id
        
        for emotion in emotions:
            emotion_dir = spk_dir / emotion
            
            if not emotion_dir.exists():
                continue
            
            emotion_lower = emotion.lower()
            
            for audio_file in sorted(emotion_dir.glob("*.wav")):
                current_file += 1
                
                # Parse filename: 0011_000001.wav
                base_name = audio_file.stem  # e.g., "0011_000001"
                utt_id = f"esd_{spk_id}_{emotion_lower}_{base_name}"
                
                # Skip if already done (resume mode)
                if utt_id in completed:
                    out_path = spk_out_dir / f"{utt_id}.wav"
                    if out_path.exists():
                        audio, sr, duration = load_audio(out_path, AUDIO["target_sr"])
                        if audio is not None:
                            trans_info = transcripts.get(base_name, {})
                            records.append({
                                "utt_id": utt_id,
                                "speaker_id": unified_spk_id,
                                "dataset": "esd",
                                "audio_path": f"audio_16k/{unified_spk_id}/{utt_id}.wav",
                                "audio_path_original": str(audio_file),
                                "duration": round(duration, 3),
                                "transcript": trans_info.get("text", ""),
                                "gender": gender,
                                "emotion": emotion_lower,
                                "accent": "American",
                            })
                    continue
                
                # Load audio (ESD is already 16kHz, but we load through librosa for consistency)
                audio, sr, duration = load_audio(audio_file, AUDIO["target_sr"])
                
                if audio is None:
                    log_data["errors"].append({
                        "utt_id": utt_id,
                        "reason": "load_failed",
                        "source": str(audio_file),
                    })
                    skipped_count += 1
                    continue
                
                # Check duration constraints
                if duration < AUDIO["min_duration"]:
                    log_data["skipped"].append({
                        "utt_id": utt_id,
                        "reason": f"too_short_{duration:.2f}s",
                        "source": str(audio_file),
                    })
                    skipped_count += 1
                    continue
                
                if duration > AUDIO["max_duration"]:
                    log_data["skipped"].append({
                        "utt_id": utt_id,
                        "reason": f"too_long_{duration:.2f}s",
                        "source": str(audio_file),
                    })
                    skipped_count += 1
                    continue
                
                # Get transcript
                trans_info = transcripts.get(base_name, {})
                transcript = trans_info.get("text", "")
                
                # Save audio
                out_path = spk_out_dir / f"{utt_id}.wav"
                save_audio(audio, out_path, AUDIO["target_sr"])
                
                # Record
                records.append({
                    "utt_id": utt_id,
                    "speaker_id": unified_spk_id,
                    "dataset": "esd",
                    "audio_path": f"audio_16k/{unified_spk_id}/{utt_id}.wav",
                    "audio_path_original": str(audio_file),
                    "duration": round(duration, 3),
                    "transcript": transcript,
                    "gender": gender,
                    "emotion": emotion_lower,
                    "accent": "American",
                })
                
                completed.add(utt_id)
                processed_count += 1
                
                # Checkpoint periodically
                if processed_count % CHECKPOINT_INTERVAL == 0:
                    save_checkpoint(checkpoint_path, completed)
                    print_progress(current_file, total_files, "ESD")
    
    # Final checkpoint
    save_checkpoint(checkpoint_path, completed)
    
    print()
    print(f"ESD complete: {processed_count} processed, {skipped_count} skipped")
    
    return records


# ============================================================
# CLEANUP: Delete files that shouldn't exist
# ============================================================

def cleanup_wrong_files(output_dir, metadata_path):
    """
    Delete any files in audio_16k that are not in metadata.csv
    This handles files created from mic1 when mic2 should have been used.
    """
    print_section("Cleanup: Removing Invalid Files")
    
    if not metadata_path.exists():
        print("No metadata.csv found - nothing to clean")
        return
    
    # Load valid utterance IDs from metadata
    df = pd.read_csv(metadata_path)
    valid_utt_ids = set(df["utt_id"].tolist())
    print(f"Valid utterances in metadata: {len(valid_utt_ids)}")
    
    # Scan all WAV files in audio_16k
    audio_dir = output_dir / "audio_16k"
    if not audio_dir.exists():
        print("No audio_16k directory - nothing to clean")
        return
    
    all_wav_files = list(audio_dir.rglob("*.wav"))
    print(f"Total WAV files found: {len(all_wav_files)}")
    
    # Find files to delete
    to_delete = []
    for wav_file in all_wav_files:
        utt_id = wav_file.stem  # filename without extension
        if utt_id not in valid_utt_ids:
            to_delete.append(wav_file)
    
    if not to_delete:
        print("No invalid files found - all clean!")
        return
    
    print(f"Found {len(to_delete)} files to delete")
    
    # Delete files
    deleted_count = 0
    for f in to_delete:
        try:
            f.unlink()
            deleted_count += 1
            if deleted_count <= 10:
                print(f"  Deleted: {f.name}")
        except Exception as e:
            print(f"  ERROR deleting {f}: {e}")
    
    if deleted_count > 10:
        print(f"  ... and {deleted_count - 10} more")
    
    print(f"Cleanup complete: {deleted_count} files deleted")
    
    # Remove empty directories
    for spk_dir in audio_dir.iterdir():
        if spk_dir.is_dir():
            remaining = list(spk_dir.glob("*.wav"))
            if not remaining:
                try:
                    spk_dir.rmdir()
                    print(f"  Removed empty directory: {spk_dir.name}")
                except:
                    pass


# ============================================================
# CREATE SPLITS
# ============================================================

def create_splits(df, output_path):
    """
    Create train/val/test splits BY SPEAKER (not by utterance).
    This tests generalization to unseen speakers.
    """
    print_section("Creating Splits")
    
    speakers = df["speaker_id"].unique()
    np.random.seed(SPLITS["seed"])
    np.random.shuffle(speakers)
    
    n_train = int(len(speakers) * SPLITS["train_ratio"])
    n_val = int(len(speakers) * SPLITS["val_ratio"])
    
    train_speakers = sorted(speakers[:n_train].tolist())
    val_speakers = sorted(speakers[n_train:n_train + n_val].tolist())
    test_speakers = sorted(speakers[n_train + n_val:].tolist())
    
    # Get utterance IDs for each split
    train_utts = df[df["speaker_id"].isin(train_speakers)]["utt_id"].tolist()
    val_utts = df[df["speaker_id"].isin(val_speakers)]["utt_id"].tolist()
    test_utts = df[df["speaker_id"].isin(test_speakers)]["utt_id"].tolist()
    
    splits = {
        "train": {
            "speakers": train_speakers,
            "utterances": train_utts,
            "num_speakers": len(train_speakers),
            "num_utterances": len(train_utts),
        },
        "val": {
            "speakers": val_speakers,
            "utterances": val_utts,
            "num_speakers": len(val_speakers),
            "num_utterances": len(val_utts),
        },
        "test": {
            "speakers": test_speakers,
            "utterances": test_utts,
            "num_speakers": len(test_speakers),
            "num_utterances": len(test_utts),
        },
        "config": {
            "train_ratio": SPLITS["train_ratio"],
            "val_ratio": SPLITS["val_ratio"],
            "test_ratio": SPLITS["test_ratio"],
            "seed": SPLITS["seed"],
            "split_by": "speaker",
        },
    }
    
    with open(output_path, 'w') as f:
        json.dump(splits, f, indent=2)
    
    print(f"Train: {len(train_speakers)} speakers, {len(train_utts)} utterances")
    print(f"Val:   {len(val_speakers)} speakers, {len(val_utts)} utterances")
    print(f"Test:  {len(test_speakers)} speakers, {len(test_utts)} utterances")
    
    return splits


# ============================================================
# PRINT SUMMARY
# ============================================================

def print_summary(df):
    """Print dataset summary statistics."""
    
    print_section("Dataset Summary")
    
    print(f"Total utterances: {len(df)}")
    print(f"Total speakers:   {df['speaker_id'].nunique()}")
    print(f"Total duration:   {df['duration'].sum() / 3600:.2f} hours")
    
    print("\nBy dataset:")
    dataset_stats = df.groupby("dataset").agg({
        "utt_id": "count",
        "speaker_id": "nunique",
        "duration": "sum"
    }).rename(columns={
        "utt_id": "utterances",
        "speaker_id": "speakers",
        "duration": "total_seconds"
    })
    dataset_stats["hours"] = dataset_stats["total_seconds"] / 3600
    print(dataset_stats[["utterances", "speakers", "hours"]].to_string())
    
    print("\nBy emotion:")
    print(df["emotion"].value_counts().to_string())
    
    print("\nBy gender:")
    print(df["gender"].value_counts().to_string())
    
    print("\nDuration statistics:")
    print(f"  Min:    {df['duration'].min():.2f}s")
    print(f"  Max:    {df['duration'].max():.2f}s")
    print(f"  Mean:   {df['duration'].mean():.2f}s")
    print(f"  Median: {df['duration'].median():.2f}s")
    
    # Show mic usage for VCTK
    vctk_df = df[df["dataset"] == "vctk"]
    if len(vctk_df) > 0:
        mic2_count = vctk_df["audio_path_original"].str.contains("mic2").sum()
        mic1_count = len(vctk_df) - mic2_count
        print(f"\nVCTK microphone usage:")
        print(f"  mic2 (clean): {mic2_count}")
        print(f"  mic1 (fallback): {mic1_count}")


# ============================================================
# MAIN
# ============================================================

def main():
    parser = argparse.ArgumentParser(description="Create unified speech dataset")
    parser.add_argument("--resume", action="store_true", help="Resume from checkpoint")
    parser.add_argument("--vctk-only", action="store_true", help="Process only VCTK")
    parser.add_argument("--esd-only", action="store_true", help="Process only ESD")
    parser.add_argument("--cleanup", action="store_true", help="Only run cleanup (delete invalid files)")
    parser.add_argument("--fresh", action="store_true", help="Delete existing unified dir and start fresh")
    args = parser.parse_args()
    
    print("=" * 60)
    print("STAGE 1: CREATE UNIFIED DATASET")
    print("=" * 60)
    print(f"Started: {datetime.now().isoformat()}")
    print(f"Output:  {UNIFIED_DIR}")
    
    # Paths
    checkpoint_path = UNIFIED_DIR / "checkpoint.json"
    log_path = UNIFIED_DIR / "processing_log.json"
    metadata_path = UNIFIED_DIR / "metadata.csv"
    splits_path = UNIFIED_DIR / "splits.json"
    
    # Fresh start - delete everything
    if args.fresh:
        print_section("Fresh Start - Deleting Existing Data")
        if UNIFIED_DIR.exists():
            import shutil
            print(f"Deleting {UNIFIED_DIR}...")
            shutil.rmtree(UNIFIED_DIR)
            print("Done")
    
    # Cleanup only mode
    if args.cleanup:
        cleanup_wrong_files(UNIFIED_DIR, metadata_path)
        return
    
    # Create output directory
    UNIFIED_DIR.mkdir(parents=True, exist_ok=True)
    
    # Load or create processing log
    log_data = load_processing_log(log_path)
    
    all_records = []
    
    # Process VCTK
    if not args.esd_only and DATASETS["vctk"]["enabled"]:
        vctk_records = process_vctk(UNIFIED_DIR, checkpoint_path, log_data, args.resume)
        all_records.extend(vctk_records)
    
    # Process ESD
    if not args.vctk_only and DATASETS["esd"]["enabled"]:
        esd_records = process_esd(UNIFIED_DIR, checkpoint_path, log_data, args.resume)
        all_records.extend(esd_records)
    
    # Save processing log
    log_data["stats"] = {
        "total_processed": len(all_records),
        "total_skipped": len(log_data["skipped"]),
        "total_errors": len(log_data["errors"]),
    }
    save_processing_log(log_path, log_data)
    
    if not all_records:
        print("\nERROR: No records processed!")
        return
    
    # Create DataFrame and save metadata
    print_section("Saving Metadata")
    df = pd.DataFrame(all_records)
    df.to_csv(metadata_path, index=False)
    print(f"Saved: {metadata_path}")
    
    # Cleanup any files that shouldn't exist
    cleanup_wrong_files(UNIFIED_DIR, metadata_path)
    
    # Create splits
    splits = create_splits(df, splits_path)
    
    # Print summary
    print_summary(df)
    
    print_section("Stage 1 Complete")
    print(f"Finished: {datetime.now().isoformat()}")
    print(f"\nOutputs:")
    print(f"  {UNIFIED_DIR}/audio_16k/          - All audio files")
    print(f"  {UNIFIED_DIR}/metadata.csv        - Metadata ({len(df)} rows)")
    print(f"  {UNIFIED_DIR}/splits.json         - Train/val/test splits")
    print(f"  {UNIFIED_DIR}/processing_log.json - Skipped files log")
    print(f"\nNext: Run stage2_extract_features.py")


if __name__ == "__main__":
    main()
