# Speech Disentanglement - Stage 1

## Quick Start

```powershell
# 1. Install dependencies
pip install -r requirements.txt

# 2. Verify paths are correct
python check_paths.py

# 3. Run preprocessing
python stage1_create_dataset.py
```

## Files

| File | Description |
|------|-------------|
| `config.py` | All configuration (paths, settings) - **EDIT THIS** |
| `utils.py` | Helper functions |
| `check_paths.py` | Verify data paths before running |
| `stage1_create_dataset.py` | Main preprocessing script |
| `requirements.txt` | Python dependencies |

## What Stage 1 Does

1. **VCTK**: Converts 48kHz FLAC → 16kHz WAV
2. **ESD**: Copies English speakers (0011-0020) only
3. **Creates** unified metadata.csv with all info
4. **Creates** train/val/test splits by speaker

## Expected Output

```
D:\InterSpeech\unified\
├── audio_16k\
│   ├── vctk_p225\
│   │   ├── vctk_p225_001.wav
│   │   └── ...
│   ├── esd_0011\
│   │   ├── esd_0011_angry_000001.wav
│   │   └── ...
│   └── ...
├── metadata.csv          # ~60,000 rows
├── splits.json           # Train/val/test by speaker
├── checkpoint.json       # For resuming
└── processing_log.json   # Skipped files
```

## Resume Support

If processing is interrupted:

```powershell
python stage1_create_dataset.py --resume
```

## Options

```powershell
# Full pipeline
python stage1_create_dataset.py

# Resume from where you left off
python stage1_create_dataset.py --resume

# Process only VCTK
python stage1_create_dataset.py --vctk-only

# Process only ESD
python stage1_create_dataset.py --esd-only
```

## Expected Time

| Dataset | Files | Time (estimate) |
|---------|-------|-----------------|
| VCTK | ~44,000 | 60-90 minutes |
| ESD | ~17,500 | 20-30 minutes |
| **Total** | **~61,500** | **~2 hours** |

## Troubleshooting

### "Path not found"

Edit `config.py` and update the paths to match your system:

```python
BASE_DIR = Path(r"D:\InterSpeech")  # Your base directory
```

### "librosa not found"

```powershell
pip install librosa soundfile
```

### "Permission denied"

Run PowerShell as Administrator, or check that no other program has the files open.
